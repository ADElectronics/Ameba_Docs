var searchData=
[
  ['_5fsleep_5fwkup_5fevent_5f',['_SLEEP_WKUP_EVENT_',['../struct___s_l_e_e_p___w_k_u_p___e_v_e_n_t__.html',1,'']]],
  ['_5fwifi_5fevent_5findicate',['_WIFI_EVENT_INDICATE',['../group__nic.html#gac57363d379bcf11345cb00cf28552615',1,'wifi_constants.h']]]
];
