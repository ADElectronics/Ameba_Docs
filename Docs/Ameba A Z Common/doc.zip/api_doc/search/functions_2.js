var searchData=
[
  ['dct_5fclose_5fmodule',['dct_close_module',['../group__dct.html#gac06e77aa8e9b984e011c4f08a4267be5',1,'dct_api.h']]],
  ['dct_5fdeinit',['dct_deinit',['../group__dct.html#ga16accef4db19ee886b39e48d2fde02ba',1,'dct_api.h']]],
  ['dct_5fdelete_5fvariable',['dct_delete_variable',['../group__dct.html#ga82a9c86c720c753f44a2aa3b05e3fc28',1,'dct_api.h']]],
  ['dct_5fget_5fvariable',['dct_get_variable',['../group__dct.html#gae42a5794c25f11534d36d4fc1d8ca7ff',1,'dct_api.h']]],
  ['dct_5finit',['dct_init',['../group__dct.html#ga78cee7e5d3bff38a57f88eaab68cdffa',1,'dct_api.h']]],
  ['dct_5fopen_5fmodule',['dct_open_module',['../group__dct.html#gab39d03bcea6a59bc714c82a153b18759',1,'dct_api.h']]],
  ['dct_5fregister_5fmodule',['dct_register_module',['../group__dct.html#ga4a3f4c8270489efc67a943a9daba04ec',1,'dct_api.h']]],
  ['dct_5fset_5fvariable',['dct_set_variable',['../group__dct.html#ga42c35b4ebf67c88106d0d836785a16cd',1,'dct_api.h']]],
  ['dct_5funregister_5fmodule',['dct_unregister_module',['../group__dct.html#gaacb34ac7b08df3351db89f1005983805',1,'dct_api.h']]],
  ['deepsleep',['deepsleep',['../group__sleep.html#ga32631ee16fdb488c270ca834cc33da8f',1,'sleep_api.h']]],
  ['deepsleep_5fex',['deepsleep_ex',['../group__sleep__ex.html#gad65d777333881159b786f5de0789ebde',1,'sleep_ex_api.h']]],
  ['deepstandby_5fex',['deepstandby_ex',['../group__sleep__ex.html#gabb5d5ab57b78c67cca30d616bb00935c',1,'deepstandby_ex(void):&#160;sleep_ex_api.h'],['../group__sleep__ex.html#gac303f28059f7dafb72cc9bdd780a415f',1,'deepstandby_ex(uint32_t sleep_duration_ms):&#160;sleep_ex_api.h']]],
  ['deinit_5fmem_5fmonitor',['deinit_mem_monitor',['../group___r_t_o_s.html#ga37363e084632199f1870b3105a7dc454',1,'osdep_service.h']]],
  ['del_5fmem_5fusage',['del_mem_usage',['../group___r_t_o_s.html#gadf74d3a405d503e2465988dffa6f1a64',1,'osdep_service.h']]],
  ['dma_5fmemcpy',['dma_memcpy',['../group__dma.html#gaeb4db1afbc2d38db2c67a8b637e6990b',1,'dma_api.h']]],
  ['dma_5fmemcpy_5faggr_5finit',['dma_memcpy_aggr_init',['../group__dma.html#ga6b4f23f4d58993ee6c68242e8facbf26',1,'dma_api.h']]],
  ['dma_5fmemcpy_5fdeinit',['dma_memcpy_deinit',['../group__dma.html#ga7e67c54d1c74e40c412df824c21e3b3f',1,'dma_api.h']]],
  ['dma_5fmemcpy_5finit',['dma_memcpy_init',['../group__dma.html#ga5946d8694c72eaa94fce1cfa7799d39d',1,'dma_api.h']]]
];
