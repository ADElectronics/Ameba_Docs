var searchData=
[
  ['dct',['DCT',['../group__dct.html',1,'']]],
  ['dma',['DMA',['../group__dma.html',1,'']]]
];
