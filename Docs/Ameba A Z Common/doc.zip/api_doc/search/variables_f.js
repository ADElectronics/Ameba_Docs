var searchData=
[
  ['tls',['tls',['../group__httpc.html#ga5419e62641a60710811bfb71146c42f1',1,'httpc_conn::tls()'],['../group__httpd.html#ga5419e62641a60710811bfb71146c42f1',1,'httpd_conn::tls()']]],
  ['tx_5fdone_5fcb',['tx_done_cb',['../group__spdio__api.html#ga4b37c0d47c8bacb2da6fa009a0a979dc',1,'spdio_t']]]
];
