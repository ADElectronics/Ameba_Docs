var searchData=
[
  ['serialfifolevel',['SerialFifoLevel',['../group__uart__ex.html#gaae69ac776dfba76a2d06c1f3bb283851',1,'serial_ex_api.h']]],
  ['serialirq',['SerialIrq',['../group__uart.html#ga8dbaa98202e6883fc0398bcc14f582b7',1,'serial_api.h']]],
  ['serialparity',['SerialParity',['../group__uart.html#ga2c48912c12fd98a4f4faffbc7f20a9f6',1,'serial_api.h']]]
];
