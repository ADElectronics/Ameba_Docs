var searchData=
[
  ['g_5fspdio_5fpriv',['g_spdio_priv',['../group__spdio__api.html#ga9adb3459a71c7d4a498970c3aa4ff249',1,'spdio_api.h']]]
];
