var searchData=
[
  ['request',['request',['../group__httpd.html#ga6b04e98412beccad0e8a2c2c0657acc8',1,'httpd_conn']]],
  ['request_5fheader',['request_header',['../group__httpc.html#gad83da9b722657013fe8230ca18484128',1,'httpc_conn']]],
  ['response',['response',['../group__httpc.html#gaa110ab24a38b8d75dd42afcf313e96f0',1,'httpc_conn']]],
  ['response_5fheader',['response_header',['../group__httpd.html#ga71aed106dbe8feb65829ea6e62d6b276',1,'httpd_conn']]],
  ['rssi',['RSSI',['../group__nic.html#ga5cb5a9a29a9e56da4545df0143540779',1,'rtw_bss_info_t']]],
  ['rx_5fdone_5fcb',['rx_done_cb',['../group__spdio__api.html#ga3a52b6476034a71dc5d882606145a387',1,'spdio_t']]]
];
