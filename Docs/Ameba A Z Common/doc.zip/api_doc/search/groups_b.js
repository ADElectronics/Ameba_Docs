var searchData=
[
  ['sleep',['SLEEP',['../group__sleep.html',1,'']]],
  ['sleep_5fex',['SLEEP_EX',['../group__sleep__ex.html',1,'']]],
  ['spdio',['SPDIO',['../group__spdio__api.html',1,'']]],
  ['spi',['SPI',['../group__spi.html',1,'']]],
  ['spi_5fex',['SPI_EX',['../group__spi__ex.html',1,'']]],
  ['system',['SYSTEM',['../group__sys.html',1,'']]]
];
