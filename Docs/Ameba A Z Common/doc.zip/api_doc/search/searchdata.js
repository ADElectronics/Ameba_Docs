var indexSectionsWithContent =
{
  0: "_abcdefghilmnopqrstuvw",
  1: "_aehioprstw",
  2: "adefghiloprstw",
  3: "acdefghilprsw",
  4: "abcdghilmnopqrstuvw",
  5: "lr",
  6: "_fmrs",
  7: "fmprt",
  8: "adefghilnprstuw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Modules"
};

