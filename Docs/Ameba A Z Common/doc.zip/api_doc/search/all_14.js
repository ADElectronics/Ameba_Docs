var searchData=
[
  ['val',['val',['../group__nic.html#ga36693d68d96d4b2cf9fc40aea6cc3ac1',1,'rtw_ssid']]],
  ['version',['version',['../group__nic.html#ga5408ac5df4c170828874e1b10b4c35a0',1,'rtw_bss_info_t::version()'],['../group__httpc.html#gaa8b9d638c9f39cd46d6f67237f8615ae',1,'http_response::version()'],['../group__httpd.html#gaa8b9d638c9f39cd46d6f67237f8615ae',1,'http_request::version()']]],
  ['version_5flen',['version_len',['../group__httpc.html#ga4a192c1f443088208aa8c39b3b7d8cbd',1,'http_response::version_len()'],['../group__httpd.html#ga4a192c1f443088208aa8c39b3b7d8cbd',1,'http_request::version_len()']]]
];
