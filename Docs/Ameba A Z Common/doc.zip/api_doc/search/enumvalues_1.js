var searchData=
[
  ['mbed_5fspi0',['MBED_SPI0',['../group__spi.html#gga023647011a0293a9aec1ca409f0013a6a5587575d5370281420a98eec392cfcf2',1,'spi_api.h']]],
  ['mbed_5fspi1',['MBED_SPI1',['../group__spi.html#gga023647011a0293a9aec1ca409f0013a6a6e42ebc26db25ba9229b81954bab191b',1,'spi_api.h']]]
];
