var searchData=
[
  ['scan_5fbuf_5farg',['scan_buf_arg',['../structscan__buf__arg.html',1,'']]],
  ['spdio_5fbuf_5ft',['spdio_buf_t',['../structspdio__buf__t.html',1,'']]],
  ['spdio_5ft',['spdio_t',['../structspdio__t.html',1,'']]]
];
